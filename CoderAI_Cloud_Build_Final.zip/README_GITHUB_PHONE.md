# Coder AI — Android Native

مشروع Android أصلي بـ Kotlin + Jetpack Compose.

## البناء من الجوال فقط

1. أنشئ حساباً في GitHub وافتح موقع GitHub من المتصفح.
2. أنشئ مستودعاً جديداً باسم `CoderAI`.
3. ارفع جميع ملفات هذا المشروع إلى المستودع.
4. افتح تبويب **Actions**.
5. اختر **Build Coder AI APK**.
6. اضغط **Run workflow**.
7. انتظر حتى تظهر علامة النجاح.
8. افتح نتيجة التشغيل، ثم من قسم **Artifacts** نزّل:
   `CoderAI-debug-apk`
9. فك ضغط الملف الناتج لتحصل على `app-debug.apk`.
10. افتح APK على هاتف Android وثبّته.

## مفتاح Gemini

قبل البناء، افتح:
`app/src/main/java/com/coderai/app/MainActivity.kt`

وابحث عن:

`private const val API_KEY = "ضع_مفتاحك_هنا"`

ضع مفتاح Gemini الخاص بك.

**تنبيه أمني:** لا تضع مفتاح API في مستودع GitHub عام. الأفضل جعل المستودع Private. والأفضل مستقبلاً إضافة شاشة داخل التطبيق لإدخال المفتاح محلياً.

## ملاحظة

الـworkflow يبني APK Debug ويرفعه كـArtifact باستخدام GitHub Actions.
GitHub يتيح تنزيل الـArtifacts من صفحة تشغيل الـworkflow.
