package com.coderai.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.content.SharedPreferences
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

data class ChatMessage(val role: String, val text: String)

class ChatViewModel : ViewModel() {
    var messages by mutableStateOf(listOf<ChatMessage>())
        private set
    var selectedModel by mutableStateOf("Gemini 3.8 Flash")
    var apiKey by mutableStateOf("")
    var isLoading by mutableStateOf(false)
        private set
    var status by mutableStateOf("جاهز")
        private set

    private val models = mapOf(
        "Gemini 3.8 Flash" to "gemini-3.8-flash",
        "Gemini 3.7 Flash" to "gemini-3.7-flash",
        "Gemini 2.5 Flash" to "gemini-2.5-flash",
        "Gemini 2.5 Pro" to "gemini-2.5-pro"
    )
    private lateinit var prefs: SharedPreferences
    private val client = OkHttpClient()

    private val systemPrompt = """
        أنت مبرمج خبير محترف بخبرة 25 سنة في كل لغات البرمجة.
        تخصصك: Python, JavaScript, TypeScript, Lua, C, C++, C#, Java, Kotlin, Swift, Go, Rust, PHP, Ruby, HTML, CSS, SQL, Bash, Assembly وغيرها.
        القواعد:
        - جاوب بالعربي، والكود بالإنجليزي.
        - اكتب كود كامل ونظيف مع تعليقات توضيحية.
        - اشرح خطوة بخطوة عند طلب الشرح.
        - صلّح الأخطاء واذكر السبب.
        - ركّز على البرمجة والتقنية فقط.
    """.trimIndent()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("coder_ai", Context.MODE_PRIVATE)
        apiKey = prefs.getString("api_key", "") ?: ""
        newChat()
    }

    fun setApiKey(context: Context, value: String) {
        apiKey = value.trim()
        context.getSharedPreferences("coder_ai", Context.MODE_PRIVATE)
            .edit().putString("api_key", apiKey).apply()
        status = if (apiKey.isBlank()) "لم يتم حفظ المفتاح" else "تم حفظ مفتاح API"
    }

    fun newChat() {
        messages = listOf(ChatMessage("model", "مرحباً 👋\nأنا مساعدك البرمجي. اكتب سؤالك وسأساعدك."))
        status = "محادثة جديدة"
    }

    fun send(text: String) {
        if (text.isBlank() || isLoading) return
        if (apiKey.isBlank()) {
            messages = messages + ChatMessage("model", "⚠️ أضف مفتاح Gemini API من زر ⚙️ الإعدادات أولاً.")
            return
        }

        val user = ChatMessage("user", text.trim())
        messages = messages + user
        isLoading = true
        status = "يفكر..."

        val history = messages.toList()
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val answer = callGemini(history)
                withContext(Dispatchers.Main) {
                    messages = messages + ChatMessage("model", answer)
                    isLoading = false
                    status = "جاهز"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    messages = messages + ChatMessage("model", "⚠️ ${e.message ?: "حدث خطأ"}")
                    isLoading = false
                    status = "حدث خطأ"
                }
            }
        }
    }

    private fun callGemini(history: List<ChatMessage>): String {
        val model = models[selectedModel] ?: "gemini-1.5-flash"
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val contents = JSONArray()
        history.forEach {
            val item = JSONObject()
            item.put("role", if (it.role == "user") "user" else "model")
            item.put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            contents.put(item)
        }

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.4))

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val msg = try { JSONObject(raw).getJSONObject("error").getString("message") } catch (_: Exception) { raw }
                throw Exception(msg)
            }
            val obj = JSONObject(raw)
            return obj.getJSONArray("candidates")
                .getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text")
        }
    }

    fun save(context: Context) {
        val text = messages.joinToString("\n\n") { "${if (it.role == "user") "أنت" else "AI"}:\n${it.text}" }
        context.openFileOutput("chat_history.txt", Context.MODE_PRIVATE).use {
            it.write(text.toByteArray(Charsets.UTF_8))
        }
        status = "تم الحفظ"
    }

    fun load(context: Context) {
        try {
            val text = context.openFileInput("chat_history.txt").bufferedReader().readText()
            messages = listOf(ChatMessage("model", text))
            status = "تم التحميل"
        } catch (e: Exception) {
            status = "لا توجد محادثة محفوظة"
        }
    }

    fun readFile(context: Context, uri: Uri) {
        try {
            val content = context.contentResolver.openInputStream(uri)?.use {
                BufferedReader(InputStreamReader(it)).readText()
            } ?: ""
            val clipped = if (content.length > 50000) content.take(50000) + "\n... (تم القص)" else content
            status = "تم رفع الملف"
            send("حلل هذا الملف واقترح تحسيناته:\n\n```text\n$clipped\n```")
        } catch (e: Exception) {
            status = "تعذر قراءة الملف"
        }
    }
}

@Composable
fun CoderAITheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Color(0xFF4EC9B0),
        secondary = Color(0xFF569CD6),
        background = Color(0xFF0B0F14),
        surface = Color(0xFF151A21),
        onBackground = Color(0xFFE6EAF0),
        onSurface = Color(0xFFE6EAF0)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: ChatViewModel) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var menuExpanded by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var keyDraft by remember(vm.apiKey) { mutableStateOf(vm.apiKey) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.readFile(LocalContext.current, it) }
    }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات Gemini") },
            text = {
                OutlinedTextField(
                    value = keyDraft,
                    onValueChange = { keyDraft = it },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("أدخل المفتاح هنا") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.setApiKey(LocalContext.current, keyDraft)
                    showSettings = false
                }) { Text("حفظ") }
            },
            dismissButton = {
                TextButton(onClick = { showSettings = false }) { Text("إلغاء") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("🤖 مساعد المبرمج", fontWeight = FontWeight.Bold)
                        Text(vm.status, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = { keyDraft = vm.apiKey; showSettings = true }) {
                        Icon(Icons.Default.Settings, "الإعدادات")
                    }
                    Box {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Default.MoreVert, "المزيد")
                        }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            DropdownMenuItem(text = { Text("محادثة جديدة") }, onClick = { vm.newChat(); menuExpanded = false })
                            DropdownMenuItem(text = { Text("حفظ") }, onClick = { vm.save(LocalContext.current); menuExpanded = false })
                            DropdownMenuItem(text = { Text("تحميل") }, onClick = { vm.load(LocalContext.current); menuExpanded = false })
                            DropdownMenuItem(text = { Text("رفع ملف") }, onClick = {
                                picker.launch(arrayOf("text/*", "application/json", "*/*"))
                                menuExpanded = false
                            })
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب سؤالك البرمجي...") },
                        maxLines = 5
                    )
                    Spacer(Modifier.width(6.dp))
                    FloatingActionButton(
                        onClick = {
                            if (input.isNotBlank()) {
                                vm.send(input)
                                input = ""
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(Icons.Default.Send, "إرسال")
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("النموذج:", fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                var expanded by remember { mutableStateOf(false) }
                Box {
                    AssistChip(
                        onClick = { expanded = true },
                        label = { Text(vm.selectedModel) },
                        trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) }
                    )
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("Gemini 2.5 Flash", "Gemini 2.5 Pro", "Gemini 3.8 Flash").forEach { name ->
                            DropdownMenuItem(text = { Text(name) }, onClick = {
                                vm.selectedModel = name
                                expanded = false
                            })
                        }
                    }
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().weight(1f),
                contentPadding = PaddingValues(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.messages) { message ->
                    MessageBubble(message)
                }
                if (vm.isLoading) {
                    item { MessageBubble(ChatMessage("model", "جاري التفكير...")) }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (user) Color(0xFF123C5A) else Color(0xFF151A21),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(14.dp),
                fontSize = 15.sp,
                color = if (user) Color(0xFFE8F3FF) else Color(0xFFE6EAF0)
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CoderAITheme {
                val vm: ChatViewModel = viewModel()
                LaunchedEffect(Unit) { vm.init(this@MainActivity) }
                MainScreen(vm)
            }
        }
    }
}
